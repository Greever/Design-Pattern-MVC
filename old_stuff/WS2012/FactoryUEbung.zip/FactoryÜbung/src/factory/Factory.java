package factory;

import sun.misc.Regexp;
import generator.*;
import iProdukte.*;

public class Factory {
	
	public void run(){
		System.out.println("Factory");
		
		//An einer zentrale Stelle wird der Typ bestimmt -> schneller Austausch
		
		//Mit Factorymethode
		//Wueste
		//Regenwald
		//Polar
        AbstractGenerator generator = AbstractGenerator.getFactory("Regenwald");
		
		//Ohne Factorymethode
		//AbstractGenerator generator = new Regenwaldgenerator();
        
        //Objekte werden erstellt 
        IPflanze pflanze = generator.createPflanze() ;
        ITier tier = generator.createTier();
        ITier tier2 = generator.createTier();
        IUntergrund untergrund = generator.createUntergrund();
        
        //Welt wird gebaut
	}
}

