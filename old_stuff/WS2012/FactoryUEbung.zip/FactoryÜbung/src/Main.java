import noFactory.*;
import factory.*;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Main");
		
		//NoFactory f = new NoFactory();
		Factory f = new Factory();
		
		f.run();
	}
}


