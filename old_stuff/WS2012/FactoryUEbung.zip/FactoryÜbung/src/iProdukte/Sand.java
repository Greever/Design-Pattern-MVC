package iProdukte;

public class Sand extends IUntergrund{

	public Sand() {
		System.out.println("Erstelle Sand");
	}
	
}
