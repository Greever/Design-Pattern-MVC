package iProdukte;

public class Kamel extends ITier{

	public Kamel() {
		System.out.println("Erstelle Kamel");
	}
}
