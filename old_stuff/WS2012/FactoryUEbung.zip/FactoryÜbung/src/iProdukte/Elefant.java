package iProdukte;

public class Elefant extends ITier{
	
	public Elefant() {
		System.out.println("Erstelle Elefant");
	}

}
