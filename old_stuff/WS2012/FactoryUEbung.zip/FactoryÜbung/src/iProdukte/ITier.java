package iProdukte;

public abstract class ITier {

}
