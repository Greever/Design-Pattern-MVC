package iProdukte;

public class Baum extends IPflanze{
	
	public Baum() {
		System.out.println("Erstelle Baum");
	}

}
