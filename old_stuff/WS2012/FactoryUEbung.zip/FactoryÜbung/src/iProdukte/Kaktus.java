package iProdukte;

public class Kaktus extends IPflanze{

	public Kaktus() {
		System.out.println("Erstelle Kaktus");
	}
}
