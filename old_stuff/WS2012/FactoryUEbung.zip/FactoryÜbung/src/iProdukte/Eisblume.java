package iProdukte;

public class Eisblume extends IPflanze{
	
	public Eisblume() {
		System.out.println("Erstelle Eisblume");
	}

}
