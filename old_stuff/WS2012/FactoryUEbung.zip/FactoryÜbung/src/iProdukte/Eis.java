package iProdukte;

public class Eis extends IUntergrund{

	public Eis() {
		System.out.println("Erstelle Eis");
	}
	
}
