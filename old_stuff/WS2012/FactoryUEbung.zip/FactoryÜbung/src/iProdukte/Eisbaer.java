package iProdukte;

public class Eisbaer extends ITier{

	public Eisbaer() {
		System.out.println("Erstelle Eisb�r");
	}
}
