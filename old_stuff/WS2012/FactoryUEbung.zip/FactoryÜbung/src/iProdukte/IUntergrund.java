package iProdukte;

public abstract class IUntergrund {

}
