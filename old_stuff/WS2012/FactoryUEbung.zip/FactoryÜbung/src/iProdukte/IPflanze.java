package iProdukte;

public abstract class IPflanze {

}
