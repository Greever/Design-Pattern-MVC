package iProdukte;

public class Gras extends IUntergrund{
	
	public Gras() {
		System.out.println("Erstelle Gras");
	}

}
