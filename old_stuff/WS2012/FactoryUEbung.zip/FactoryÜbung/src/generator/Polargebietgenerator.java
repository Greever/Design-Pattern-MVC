package generator;

import iProdukte.*;

public class Polargebietgenerator extends AbstractGenerator{
    
	public Polargebietgenerator() {
		System.out.println("Erstelle Polargebiet");
	}
	
	public ITier createTier(){
        return new Eisbaer();
    }
    public IPflanze createPflanze(){
        return new Eisblume();
    }
    public IUntergrund createUntergrund(){
        return new Eis();
    }

}
