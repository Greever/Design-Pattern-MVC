package generator;

import iProdukte.*;

public abstract class AbstractGenerator {

    public abstract ITier createTier();
    public abstract IPflanze createPflanze();
    public abstract IUntergrund createUntergrund();
    
    public static AbstractGenerator getFactory(String variante){
    	AbstractGenerator retVal = null;
    	
    	if(variante.equals("Wueste"))
    		retVal = new Wuestengenerator();
    	else if(variante.equals("Regenwald"))
    		retVal = new Regenwaldgenerator();
    	else if(variante.equals("Polar"))
    		retVal = new Polargebietgenerator();
    	return retVal;
    }
    
    
}
