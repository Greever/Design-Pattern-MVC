package generator;

import iProdukte.*;

public class Wuestengenerator extends AbstractGenerator{
	
	public Wuestengenerator() {
		System.out.println("Erstelle Wueste");
	}
	
    public ITier createTier(){
        return new Kamel();
    }
    public IPflanze createPflanze(){
        return new Kaktus();
    }
    public IUntergrund createUntergrund(){
        return new Sand();
    }

}
