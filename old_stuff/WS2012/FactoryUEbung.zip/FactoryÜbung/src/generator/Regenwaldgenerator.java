package generator;

import iProdukte.*;

public class Regenwaldgenerator extends AbstractGenerator {
    
	public Regenwaldgenerator() {
		System.out.println("Erstelle Regenwald");
	}
	
	public ITier createTier(){
        return new Elefant();
    }
    public IPflanze createPflanze(){
        return new Baum();
    }
    public IUntergrund createUntergrund(){
        return new Gras();
    }

}
