package produkte;

public class Baum {

	public Baum() {
		System.out.println("Erstelle Baum");
	}
}
