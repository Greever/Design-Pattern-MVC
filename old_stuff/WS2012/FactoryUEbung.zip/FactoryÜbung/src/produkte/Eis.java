package produkte;

public class Eis {
	public Eis() {
		System.out.println("Erstelle Eis");
	}
}
