package produkte;

public class Kaktus {
	public Kaktus() {
		System.out.println("Erstelle Kaktus");
	}
}
