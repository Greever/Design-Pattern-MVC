package produkte;

public class Gras {
	public Gras() {
		System.out.println("Erstelle Gras");
	}
}
