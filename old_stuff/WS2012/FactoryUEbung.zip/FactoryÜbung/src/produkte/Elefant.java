package produkte;

public class Elefant {
	public Elefant() {
		System.out.println("Erstelle Elefant");
	}
}
