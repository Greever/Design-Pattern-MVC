package produkte;

public class Sand {
	public Sand() {
		System.out.println("Erstelle Sand");
	}
}
