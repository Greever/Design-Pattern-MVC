package produkte;

public class Eisblume {
	public Eisblume() {
		System.out.println("Erstelle Eisblume");
	}

}
