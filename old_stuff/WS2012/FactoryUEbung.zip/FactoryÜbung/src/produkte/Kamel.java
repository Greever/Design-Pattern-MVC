package produkte;

public class Kamel {
	public Kamel() {
		System.out.println("Erstelle Kamel");
	}
}
