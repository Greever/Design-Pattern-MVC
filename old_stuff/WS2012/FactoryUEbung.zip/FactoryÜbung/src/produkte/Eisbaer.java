package produkte;

public class Eisbaer {
	public Eisbaer() {
		System.out.println("Erstelle Eisbaer");
	}
}
