package noFactory;

import produkte.*;


public class Polargebietgenerator {
	
	public Polargebietgenerator() {
		System.out.println("Erstelle Polargebiet");
	}
		

    public Eisbaer createEisbaer(){
        return new Eisbaer();
    }
    public Eisblume createEisblume(){
        return new Eisblume();
    }
    public Eis createEis(){
        return new Eis();
    }

}
