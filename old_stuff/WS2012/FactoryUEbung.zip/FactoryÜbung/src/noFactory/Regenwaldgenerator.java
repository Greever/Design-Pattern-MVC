package noFactory;

import produkte.*;

public class Regenwaldgenerator {

	public Regenwaldgenerator() {
		System.out.println("Erstelle Regenwald");
	}

	public Elefant createElefant() {
		return new Elefant();
	}

	public Baum createBaum() {
		return new Baum();
	}

	public Gras createGras() {
		return new Gras();
	}
}
