package noFactory;

import produkte.*;

public class NoFactory {
	
	public void run(){
		System.out.println("NoFactory");
		
        //Flags die bestimmen, welchen Weltentyp der Client bauen soll
        boolean regenwald = true;
        boolean polargebiet = false;
        boolean w�ste = false;
        
        //Elemente holen
        if (regenwald){
            Regenwaldgenerator regenwaldgenerator = new Regenwaldgenerator();
            Baum baum1 = regenwaldgenerator.createBaum();
            Baum baum2 = regenwaldgenerator.createBaum();
            Elefant elefant = regenwaldgenerator.createElefant();
            Gras gras = regenwaldgenerator.createGras();
            //Welt zusammen setzten...
        } else if (w�ste){
            Wuestengenerator w�stengenerator = new Wuestengenerator();
            Kaktus kaktus1 = w�stengenerator.createKaktus();
            Kaktus kaktus2 = w�stengenerator.createKaktus();
            Kamel kamel = w�stengenerator.createKamel();
            Sand sand = w�stengenerator.createSand();
            //Welt zusammen setzten...
        } else if (polargebiet){
            Polargebietgenerator polargebietgenerator = new Polargebietgenerator();
            Eisblume eisblume1 = polargebietgenerator.createEisblume();
            Eisblume eisblume2 = polargebietgenerator.createEisblume();
            Eisbaer eisbaer = polargebietgenerator.createEisbaer();
            Eis eis = polargebietgenerator.createEis();
            //Welt zusammen setzten...
        }
		
	}
}
