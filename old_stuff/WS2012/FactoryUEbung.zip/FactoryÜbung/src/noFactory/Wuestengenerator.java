package noFactory;

import produkte.*;


public class Wuestengenerator {

	public Wuestengenerator() {
		System.out.println("Erstelle Wueste");
	}
	
    public Kamel createKamel(){
        return new Kamel();
    }
    public Kaktus createKaktus(){
        return new Kaktus();
    }
    public Sand createSand(){
        return new Sand();
    }
}
