package uebungObserver;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.JProgressBar;
import javax.swing.JToggleButton;

public class FormNumericalView extends JDialog implements MouseListener {

	private final JPanel contentPanel = new JPanel();

	private FormData myData;
	private JButton tglbtnPlus;
	private JButton tglbtnMinus;
	private JTextArea textField;
	/**
	 * Create the dialog.
	 */
	public FormNumericalView(FormData myData) {
		setTitle("FormNumericalView");
		setBounds(100, 100, 450, 300);
		try {
			
			this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			this.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.setLocation(0, 500);
		this.myData = myData;
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			textField = new JTextArea();
			textField.setEnabled(false);
			textField.setText("0");
			textField.setBounds(10, 85, 253, 31);
			contentPanel.add(textField);
		}
		
		tglbtnPlus = new JButton("+");
		tglbtnPlus.setBounds(10, 195, 121, 23);
		contentPanel.add(tglbtnPlus);
		tglbtnPlus.addMouseListener(this);
		
		tglbtnMinus = new JButton("-");
		tglbtnMinus.setBounds(142, 195, 121, 23);
		contentPanel.add(tglbtnMinus);
		tglbtnMinus.addMouseListener(this);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
	}


	@Override
	public void mouseClicked(MouseEvent arg0) {

		if(arg0.getSource() == this.tglbtnMinus)
		{
			this.minusClicked();
		}
		
		if(arg0.getSource() == this.tglbtnPlus)
		{
			this.plusClicked();
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	private void plusClicked()
	{
		int newValue = this.myData.getValue() + 10;
		
		this.textField.setText(Integer.toString(newValue));
		this.myData.setValue(newValue);
	}
	private void minusClicked()
	{
		int newValue = this.myData.getValue() - 10;
		
		this.textField.setText(Integer.toString(newValue));
		this.myData.setValue(newValue);
	}



	
}
