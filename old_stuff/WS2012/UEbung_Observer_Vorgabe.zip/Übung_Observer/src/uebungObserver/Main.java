package uebungObserver;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FormData d=new FormData();
		
		FormGraphicalView o1 = new FormGraphicalView(d);
		FormNumericalView o2 = new FormNumericalView(d);
		
	}

}
